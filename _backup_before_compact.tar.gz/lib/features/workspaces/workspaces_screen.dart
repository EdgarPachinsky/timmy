import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/models.dart';
import '../../state/auth_controller.dart';
import '../../state/workspaces_controller.dart';
import '../../widgets/common.dart';
import '../shell/user_menu.dart';

class WorkspacesScreen extends StatelessWidget {
  const WorkspacesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<WorkspacesController>();
    final user = context.watch<AuthController>().user;
    final workspaces = controller.workspaces;

    Widget body;
    if (workspaces == null) {
      body = controller.error != null
          ? ErrorState(message: controller.error!, onRetry: controller.load)
          : const Center(child: CircularProgressIndicator());
    } else if (workspaces.isEmpty) {
      body = const EmptyState(
        icon: Icons.workspaces_outline,
        message: "You aren't a member of any workspace yet.",
      );
    } else {
      body = ListView.separated(
        shrinkWrap: true,
        itemCount: workspaces.length,
        separatorBuilder: (_, _) => const SizedBox(height: 12),
        itemBuilder: (context, i) => _WorkspaceCard(
          workspace: workspaces[i],
          onTap: () => controller.select(workspaces[i]),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Timmy'),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            onPressed: controller.loading ? null : controller.load,
            icon: const Icon(Icons.refresh),
          ),
          if (user != null) UserMenu(user: user),
          const SizedBox(width: 12),
        ],
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 640),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 24),
                Text(
                  'Choose a workspace',
                  style: Theme.of(context)
                      .textTheme
                      .headlineSmall
                      ?.copyWith(fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 4),
                Text(
                  user == null ? '' : 'Signed in as ${user.name}',
                  style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
                ),
                const SizedBox(height: 24),
                Flexible(child: body),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _WorkspaceCard extends StatelessWidget {
  const _WorkspaceCard({required this.workspace, required this.onTap});

  final Workspace workspace;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              CircleAvatar(
                radius: 24,
                backgroundColor: scheme.primaryContainer,
                child: Text(
                  workspace.name.isEmpty ? '?' : workspace.name[0].toUpperCase(),
                  style: theme.textTheme.titleLarge?.copyWith(color: scheme.onPrimaryContainer),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            workspace.name,
                            overflow: TextOverflow.ellipsis,
                            style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Chip(
                          label: Text(workspace.myRole),
                          visualDensity: VisualDensity.compact,
                          padding: EdgeInsets.zero,
                          labelStyle: theme.textTheme.labelSmall,
                        ),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${workspace.memberCount} members · ${workspace.projectCount} projects · ${workspace.timezone}',
                      style: theme.textTheme.bodySmall?.copyWith(color: scheme.onSurfaceVariant),
                    ),
                  ],
                ),
              ),
              Icon(Icons.chevron_right, color: scheme.onSurfaceVariant),
            ],
          ),
        ),
      ),
    );
  }
}
