import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/format.dart';
import '../../models/models.dart';
import '../../state/workspace_session.dart';
import '../../widgets/common.dart';

class ProjectsPage extends StatefulWidget {
  const ProjectsPage({super.key, required this.onTrack});

  /// Called when the user wants to track time against a project.
  final ValueChanged<Project> onTrack;

  @override
  State<ProjectsPage> createState() => _ProjectsPageState();
}

class _ProjectsPageState extends State<ProjectsPage> {
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final session = context.watch<WorkspaceSession>();
    final theme = Theme.of(context);
    final projects = session.projects;

    final filtered = [
      for (final p in projects.data ?? const <Project>[])
        if (_query.isEmpty ||
            p.name.toLowerCase().contains(_query) ||
            (p.client?.fullName.toLowerCase().contains(_query) ?? false))
          p,
    ]..sort((a, b) {
        // Active projects first, then alphabetical.
        if (a.isActive != b.isActive) return a.isActive ? -1 : 1;
        return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      });

    Widget body;
    if (projects.data == null) {
      body = projects.error != null
          ? ErrorState(message: projects.error!, onRetry: session.loadProjects)
          : const Center(child: CircularProgressIndicator());
    } else if (filtered.isEmpty) {
      body = EmptyState(
        icon: Icons.folder_off_outlined,
        message: _query.isEmpty ? 'No projects assigned to you yet.' : 'No projects match "$_query".',
      );
    } else {
      body = ListView.separated(
        itemCount: filtered.length,
        separatorBuilder: (_, _) => const SizedBox(height: 10),
        itemBuilder: (context, i) => _ProjectTile(
          project: filtered[i],
          onTrack: () => widget.onTrack(filtered[i]),
        ),
      );
    }

    return Align(
      alignment: Alignment.topCenter,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 760),
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      'Projects',
                      style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w700),
                    ),
                  ),
                  IconButton(
                    tooltip: 'Refresh',
                    onPressed: projects.loading ? null : session.loadProjects,
                    icon: const Icon(Icons.refresh),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              TextField(
                decoration: const InputDecoration(
                  hintText: 'Search projects or clients',
                  prefixIcon: Icon(Icons.search),
                  isDense: true,
                ),
                onChanged: (v) => setState(() => _query = v.trim().toLowerCase()),
              ),
              if (projects.data != null && projects.error != null) ...[
                const SizedBox(height: 12),
                InlineNotice(
                  message: "Couldn't refresh: ${projects.error}",
                  icon: Icons.error_outline,
                  isError: true,
                  actions: [TextButton(onPressed: session.loadProjects, child: const Text('Retry'))],
                ),
              ],
              const SizedBox(height: 16),
              Expanded(child: body),
            ],
          ),
        ),
      ),
    );
  }
}

class _ProjectTile extends StatelessWidget {
  const _ProjectTile({required this.project, required this.onTrack});

  final Project project;
  final VoidCallback onTrack;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final muted = theme.colorScheme.onSurfaceVariant;
    final client = project.client?.fullName;
    final details = [
      if (client != null && client.isNotEmpty) client,
      '${project.memberCount} members',
      '${formatMinutes(project.totalMinutes)} tracked',
    ].join(' · ');

    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            ColorDot(project.color, size: 14),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          project.name,
                          overflow: TextOverflow.ellipsis,
                          style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600),
                        ),
                      ),
                      if (!project.isActive) ...[
                        const SizedBox(width: 8),
                        Chip(
                          label: Text(project.status),
                          visualDensity: VisualDensity.compact,
                          padding: EdgeInsets.zero,
                          labelStyle: theme.textTheme.labelSmall,
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text(details, style: theme.textTheme.bodySmall?.copyWith(color: muted)),
                ],
              ),
            ),
            const SizedBox(width: 12),
            OutlinedButton.icon(
              onPressed: project.isActive ? onTrack : null,
              icon: const Icon(Icons.play_arrow_rounded, size: 20),
              label: const Text('Track'),
            ),
          ],
        ),
      ),
    );
  }
}
