import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/api_client.dart';
import '../../core/clock.dart';
import '../../core/storage.dart';
import '../../models/models.dart';
import '../../state/auth_controller.dart';
import '../../state/tracker_controller.dart';
import '../../state/workspace_session.dart';
import '../../state/workspaces_controller.dart';
import '../entries/entries_page.dart';
import '../projects/projects_page.dart';
import '../tracker/elapsed_text.dart';
import '../tracker/tracker_page.dart';
import 'user_menu.dart';

/// The signed-in app for one workspace: side navigation plus the three pages.
class WorkspaceShell extends StatelessWidget {
  const WorkspaceShell({super.key, required this.workspace});

  final Workspace workspace;

  @override
  Widget build(BuildContext context) {
    final user = context.read<AuthController>().user!;
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (c) => WorkspaceSession(
            api: c.read<ApiClient>(),
            workspace: workspace,
            user: user,
          )..loadAll(),
        ),
        ChangeNotifierProvider(
          create: (c) {
            final session = c.read<WorkspaceSession>();
            return TrackerController(
              api: c.read<ApiClient>(),
              storage: c.read<AppStorage>(),
              user: user,
              workspace: workspace,
              onEntrySaved: session.loadEntries,
              now: c.read<Clock>(),
            );
          },
        ),
      ],
      child: _ShellScaffold(workspace: workspace, user: user),
    );
  }
}

class _ShellScaffold extends StatefulWidget {
  const _ShellScaffold({required this.workspace, required this.user});

  final Workspace workspace;
  final User user;

  @override
  State<_ShellScaffold> createState() => _ShellScaffoldState();
}

class _ShellScaffoldState extends State<_ShellScaffold> {
  static const _trackerIndex = 0;
  int _index = _trackerIndex;

  void _trackProject(Project project) {
    final tracker = context.read<TrackerController>();
    if (tracker.isActive) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Finish the running timer before switching projects.'),
      ));
    } else {
      tracker.setProject(project);
    }
    setState(() => _index = _trackerIndex);
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final tracker = context.watch<TrackerController>();

    return Scaffold(
      body: Row(
        children: [
          NavigationRail(
            extended: true,
            minExtendedWidth: 232,
            selectedIndex: _index,
            onDestinationSelected: (i) => setState(() => _index = i),
            backgroundColor: scheme.surfaceContainerLow,
            leading: _WorkspaceHeader(
              workspace: widget.workspace,
              canSwitch: !tracker.isActive,
            ),
            trailing: Expanded(
              child: Align(
                alignment: Alignment.bottomCenter,
                child: _RailFooter(
                  user: widget.user,
                  // The big clock is already on screen in the tracker tab.
                  showTimer: _index != _trackerIndex,
                  onOpenTracker: () => setState(() => _index = _trackerIndex),
                ),
              ),
            ),
            destinations: const [
              NavigationRailDestination(
                icon: Icon(Icons.timer_outlined),
                selectedIcon: Icon(Icons.timer),
                label: Text('Time tracker'),
              ),
              NavigationRailDestination(
                icon: Icon(Icons.folder_outlined),
                selectedIcon: Icon(Icons.folder),
                label: Text('Projects'),
              ),
              NavigationRailDestination(
                icon: Icon(Icons.list_alt_outlined),
                selectedIcon: Icon(Icons.list_alt),
                label: Text('Time entries'),
              ),
            ],
          ),
          VerticalDivider(width: 1, color: scheme.outlineVariant),
          Expanded(
            // IndexedStack keeps each page's state (e.g. half-typed form text).
            child: IndexedStack(
              index: _index,
              children: [
                const TrackerPage(),
                ProjectsPage(onTrack: _trackProject),
                const EntriesPage(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _WorkspaceHeader extends StatelessWidget {
  const _WorkspaceHeader({required this.workspace, required this.canSwitch});

  final Workspace workspace;
  final bool canSwitch;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    return SizedBox(
      width: 232,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 20, 8, 12),
        child: Row(
          children: [
            CircleAvatar(
              radius: 18,
              backgroundColor: scheme.primaryContainer,
              child: Text(
                workspace.name.isEmpty ? '?' : workspace.name[0].toUpperCase(),
                style: TextStyle(color: scheme.onPrimaryContainer, fontWeight: FontWeight.w700),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    workspace.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
                  ),
                  Text(
                    workspace.timezone,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.bodySmall?.copyWith(color: scheme.onSurfaceVariant),
                  ),
                ],
              ),
            ),
            IconButton(
              tooltip: canSwitch ? 'Switch workspace' : 'End the running timer to switch workspace',
              icon: const Icon(Icons.swap_horiz),
              onPressed: canSwitch ? () => context.read<WorkspacesController>().clearSelection() : null,
            ),
          ],
        ),
      ),
    );
  }
}

class _RailFooter extends StatelessWidget {
  const _RailFooter({
    required this.user,
    required this.showTimer,
    required this.onOpenTracker,
  });

  final User user;
  final bool showTimer;
  final VoidCallback onOpenTracker;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final tracker = context.watch<TrackerController>();

    return SizedBox(
      width: 232,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (tracker.isActive && showTimer) ...[
              Material(
                color: scheme.primaryContainer,
                borderRadius: BorderRadius.circular(12),
                child: InkWell(
                  borderRadius: BorderRadius.circular(12),
                  onTap: onOpenTracker,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    child: Row(
                      children: [
                        Icon(
                          tracker.isRunning ? Icons.fiber_manual_record : Icons.pause_circle_filled,
                          size: 14,
                          color: tracker.isRunning ? scheme.error : scheme.onPrimaryContainer,
                        ),
                        const SizedBox(width: 10),
                        ElapsedText(
                          controller: tracker,
                          style: theme.textTheme.titleMedium!.copyWith(
                            fontWeight: FontWeight.w700,
                            color: scheme.onPrimaryContainer,
                          ),
                        ),
                        const Spacer(),
                        Flexible(
                          child: Text(
                            tracker.projectName,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: theme.textTheme.bodySmall?.copyWith(color: scheme.onPrimaryContainer),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),
            ],
            Row(
              children: [
                UserMenu(user: user),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    user.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.bodyMedium,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
